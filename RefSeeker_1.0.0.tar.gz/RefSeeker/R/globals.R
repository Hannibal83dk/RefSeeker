utils::globalVariables("Normfinder")


