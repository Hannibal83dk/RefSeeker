## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(RefSeeker)

## ----eval=FALSE---------------------------------------------------------------
#  exceldata <- rsloaddata()

## -----------------------------------------------------------------------------
exceldata <- rs_loaddata("../inst/exdata/vignetteInputs/RefSeeker_data_test.xlsx")

exceldata

## ----eval=FALSE---------------------------------------------------------------
#  exceldata$Fresh_Frozen

## -----------------------------------------------------------------------------
exceldata[[1]]

