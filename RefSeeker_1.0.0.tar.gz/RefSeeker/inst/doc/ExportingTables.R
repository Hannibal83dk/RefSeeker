## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(RefSeeker)

## -----------------------------------------------------------------------------
rs_data <- rs_loaddata("../inst/exdata/vignetteInputs/RefSeeker_data_test.xlsx")
rs_results <- rs_reffinder(rs_data)

rs_results

## ----eval = FALSE-------------------------------------------------------------
#  rs_exporttable(rs_results, filename = "cohort1", tabletype = "xlsx", addDate = FALSE)

## ----eval = FALSE-------------------------------------------------------------
#  rs_exporttable(rs_results, filename = "cohort1", tabletype = "ods")

## ----eval = FALSE-------------------------------------------------------------
#  rs_exporttable(rs_results, filename = "cohort1", tabletype = "csv")
#  rs_exporttable(rs_results, filename = "cohort1", tabletype = "tsv")
#  rs_exporttable(rs_results, filename = "cohort1", tabletype = "txt")

## ----eval = FALSE-------------------------------------------------------------
#  rs_exporttable(rs_results, filename = "cohort1", tabletype = "docx-stability")

## ----eval = FALSE-------------------------------------------------------------
#  rs_exporttable(rs_results, filename = "./cohort1", tabletype = "docx-rank")

## ----eval = FALSE-------------------------------------------------------------
#  rs_exporttable(rs_results, filename = "cohort1", tabletype = "docx-combi")

