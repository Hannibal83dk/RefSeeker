## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(RefSeeker)

## ----eval = FALSE-------------------------------------------------------------
#  rs_wizard()

## -----------------------------------------------------------------------------

inputData <- rs_loaddata("../inst/exdata/vignetteInputs/RefSeeker_data_vignetteSample.xlsx")

## -----------------------------------------------------------------------------
rs_normfinder(inputData$Fresh_Frozen)

## -----------------------------------------------------------------------------
rs_genorm(inputData$Fresh_Frozen)

## -----------------------------------------------------------------------------
rs_bestkeeper(inputData$Fresh_Frozen)

## -----------------------------------------------------------------------------
rs_deltact(inputData$Fresh_Frozen)

## -----------------------------------------------------------------------------
rsresults <- rs_reffinder(inputData)
rsresults


## ----eval = FALSE-------------------------------------------------------------
#  rs_exporttable(rsresults$Fresh_Frozen, "../inst/exdata/VignettesOutputs/excel_results", tabletype = "xlsx", addDate = TRUE)
#  

## ----fig.asp = 1, fig.width = 9, out.width="99%", fig.align='center'----------

rs_graph(rsresults)


## ----eval = FALSE-------------------------------------------------------------
#  
#  rs_graph(rsresults, "../inst/exdata/VignettesOutputs/refSeeker_excel_results", forceSingle = TRUE)
#  

