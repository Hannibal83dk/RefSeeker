## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(RefSeeker)

## -----------------------------------------------------------------------------
rs_data <- rs_loaddata("../inst/exdata/vignetteInputs/RefSeeker_data_test.xlsx")
rs_results <- rs_reffinder(rs_data)

rs_results

## ----quick-view-graph, fig.asp = 0.5, fig.height = 6, fig.width = 9, out.width="99%", fig.align='center'----
multigraph <- rs_graph(rs_results)

## ----individual-graphs, fig.asp = 0.3, fig.height = 6, fig.width = 9, out.width="99%", fig.align='center'----
singlegraphs <- rs_graph(rs_results, forceSingle = TRUE)

## ----demoing-target, fig.asp = 0.5, fig.height = 6, fig.width = 9, out.width="99%", fig.align='center'----
singlegraphs <- rs_graph(rs_results, ordering = "Target")

## ----demoing-singlecolor, fig.asp = 0.5, fig.height = 6, fig.width = 9, out.width="99%", fig.align='center'----
singlegraphs <- rs_graph(rs_results, colors = "#2271b2")

## -----------------------------------------------------------------------------
colors <- data.frame(target = names(rs_data$FFPE),

                     color = c("#2271b2",
                               "#2271b2",
                               "#2271b2",
                               "#2271b2",
                               "#359b73",
                               "#d55e00",
                               "#d55e00",
                               "#d55e00",
                               "#d55e00",
                               "#d55e00"))
colors

## -----------------------------------------------------------------------------

colors <- data.frame(target = c("UniSp2",
                                "UniSp4",
                                "UniSp6",
                                "cel-miR-39-3p",
                                "UniSp3_IPC",
                                "hsa-miR-30c-5p",
                                "hsa-miR-103a-3p",
                                "hsa-miR-191-5p",
                                "hsa-miR-23a-3p",
                                "hsa-miR-451a"), 
                      
                     color = c("#2271b2",
                                "#2271b2",
                                "#2271b2",
                                "#2271b2",
                                "#359b73",
                                "#d55e00",
                                "#d55e00",
                                "#d55e00",
                                "#d55e00",
                                "#d55e00")
)
colors

## ----demoing-multicolor, fig.asp = 0.5, fig.height = 6, fig.width = 9, out.width="99%", fig.align='center'----
singlegraphs <- rs_graph(rs_results, colors = colors)

## ----demoing-vertical, fig.asp = 1.25, fig.height = 12, fig.width = 8, out.width="75%", fig.align='center'----
singlegraphs <- rs_graph(rs_results, colors = colors, orientation = "vertical")

## ----eval=FALSE---------------------------------------------------------------
#  singlegraphs <- rs_graph(rs_results, filename = "Demo-graph", filetype = "svg", colors = colors, orientation = "vertical")

