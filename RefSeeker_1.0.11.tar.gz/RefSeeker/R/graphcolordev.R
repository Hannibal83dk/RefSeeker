# library(RefSeeker)
#
# file <- file.choose()
#
# data <- rs_loaddata()
#
# Fresh_frozen <- rs_reffinder(data$Fresh_Frozen)
#
# resultsAll <- rs_reffinder(data)
#
# Fresh_frozenList <- Fresh_frozenList[1]
#
#
# rs_graph(resultsAll)
#
# colors <- data.frame(targets = names(data[[1]]), color = c("#b34126", "#d9ad4c", "#88b5de", "#1c440b", "#374f65"))
# rs_graph(resultsAll, colors = colors, forceSingle = T)
#
#
# refseekerlist <- resultsAll
#
#
# Fresh_frozen <- results$Fresh_Frozen
#
# rs_graph(results, f, forceSingle = T)
#
#
#
#


