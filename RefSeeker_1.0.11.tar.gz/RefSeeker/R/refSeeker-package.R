#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom ggplot2 ggplot
#' @importFrom reshape2 melt
## usethis namespace: end
NULL
