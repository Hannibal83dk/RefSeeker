## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(refSeeker)

## ----eval = FALSE-------------------------------------------------------------
#  rs_batchExcel3()
#  rs_csvbatch() # may be used for tsv or txt files also

## -----------------------------------------------------------------------------

inputData <- rs_loadexceldata("../inst/exdata/vignetteInputs/Reffinder_data_test.xlsx")

## -----------------------------------------------------------------------------
rs_normfinder(inputData$Fresh_Frozen)

## -----------------------------------------------------------------------------
rs_genorm(inputData$Fresh_Frozen)

## -----------------------------------------------------------------------------
rs_bestKeeper(inputData$Fresh_Frozen)

## -----------------------------------------------------------------------------
rs_deltaCt(inputData$Fresh_Frozen)

## -----------------------------------------------------------------------------
rsresults <- rs_reffinder(inputData)
rsresults


## -----------------------------------------------------------------------------
rs_exceltable(rsresults$Fresh_Frozen, "../inst/exdata/VignettesOutputs/excel_results", addDate = TRUE)


## ----fig.asp = 1, fig.width = 9, out.width="99%", fig.align='center'----------

rs_graph(rsresults)


## ----fig.show='hide'----------------------------------------------------------

rs_graph(rsresults, "../inst/exdata/VignettesOutputs/refSeeker_excel_results", forceSingle = TRUE, width = 1024)


