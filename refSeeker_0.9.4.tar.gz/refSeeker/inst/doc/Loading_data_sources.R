## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(refSeeker)

## ----eval=FALSE---------------------------------------------------------------
#  exceldata <- rs_loadexceldata()

## -----------------------------------------------------------------------------
exceldata <- rs_loadexceldata("../inst/exdata/vignetteInputs/Reffinder_data_test.xlsx")

exceldata

## ----eval=FALSE---------------------------------------------------------------
#  exceldata$Fresh_Frozen

## -----------------------------------------------------------------------------
exceldata[[1]]

