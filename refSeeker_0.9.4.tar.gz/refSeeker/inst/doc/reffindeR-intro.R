## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(refSeeker)

## ----data example 1-----------------------------------------------------------
set.seed(100)
ct_vals <- matrix(rnorm(5*20, mean = 25), ncol = 5, nrow = 20)
dimnames(ct_vals)[[2]] <-  c("gene1", "gene2", "gene3", "gene4", "gene5")
ct_vals

## -----------------------------------------------------------------------------
rs_results <- rs_reffinder(ct_vals)
rs_results

## ----eval=FALSE---------------------------------------------------------------
#  rs_exceltable(rs_results, "./output/folder/sample_excel_tables")

## ----refSeeker-intro_fig, fig.asp = 1, fig.width = 9, out.width="99%", fig.align='center'----
rs_graph(rs_results)


## ----eval=FALSE---------------------------------------------------------------
#  rs_graph(rs_results, "./output/folder/Sample stability", outputPng = TRUE)
#  

## ----eval=FALSE---------------------------------------------------------------
#  rs_batchExcel()

