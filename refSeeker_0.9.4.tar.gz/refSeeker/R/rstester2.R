# library(refSeeker)
#
#
# exceldata <- rs_loadexceldata()
#
# file.choose()
#
# exceldata <- rs_loadexceldata("/media/patrick/Storage/reffindeR/inst/exdata/exceltest/refSeeker_data_test.xlsx")
#
# exceldata$Fresh_Frozen
# exceldata[[1]]
#
#
# rfder <- rf_reffinder(exceldata)
#
# rs_graph(rfder)
