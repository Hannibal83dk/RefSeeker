## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(refSeeker)

## ----eval=FALSE---------------------------------------------------------------
#  exceldata <- rsloaddata()

## -----------------------------------------------------------------------------
exceldata <- rs_loaddata("../inst/exdata/vignetteInputs/Reffinder_data_test.xlsx")

exceldata

## ----eval=FALSE---------------------------------------------------------------
#  exceldata$Fresh_Frozen

## -----------------------------------------------------------------------------
exceldata[[1]]

